import React from "react";
import Item from "./Item";

const ItemList = ({array}) => {
 
    return(
     <>
     {array.map( (producto) =>(
      <Item producto={producto} />
    )   
    ) } 
    </>
    )

}

export default ItemList