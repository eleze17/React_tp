import {React} from "react";


const Itemdetail = ({detalle}) =>  {

return(
    <>
    <div
      className="offcanvas offcanvas-end"
      tabIndex={-1}
      id="offcanvasRight"
      aria-labelledby="offcanvasRightLabel"
    >
      <div className="offcanvas-header">
        <h5 className="offcanvas-title" id="offcanvasRightLabel">
          Detalle del producto: 
        </h5>
        <button
          type="button"
          className="btn-close"
          data-bs-dismiss="offcanvas"
          aria-label="Close"
        />
      </div>
      <div className="offcanvas-body">
        <img src={detalle}></img>
        {console.log(detalle)}
      </div>
    </div>
  </>
  
)  
}
export default Itemdetail