import {React,useState,useEffect} from "react";
import productos from "./Productos";
import {verproduct} from './ItemListContainer'
import ItemCount from './ItemCount'
import Itemdetail from "./Itemdetail";

    const ItemDetailContainer = ({producto}) =>{
        let pbuscado = []
        const [det,setDetalle] = useState([])
    useEffect( () =>{ 
        verproduct(true)
        .then(res => {
            setDetalle(res )
            
          })
        .catch(error=> {
            console.log(error)
                  }) 
                },[])    

     
            det.forEach(detalle=>
            detalle.titulo == producto.titulo ? pbuscado = (detalle): 'nada')
                
         
            console.log(pbuscado.titulo)
        
         return(
            <>
            <button className="btn btn-primary" type="button" 
            data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" 
            aria-controls="offcanvasRight"
            >{pbuscado.titulo}
            {pbuscado.picture}
            
            </button>  
            {console.log(pbuscado.picture)}
            <Itemdetail detalle = {pbuscado.picture} />
                      
                     
        
            </>
                   )
    }

    

export default  ItemDetailContainer