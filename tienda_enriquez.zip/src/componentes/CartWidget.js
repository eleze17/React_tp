import React from "react";

const CartWidget = () => {
return(
    <picture className="pict">
        <img className="logo" src="..\Imagenes\icono.png">
        </img>

    </picture>  );
}
export default CartWidget;