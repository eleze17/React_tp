import './App.css';
import Nabvar from  "./componentes/Nabvar";
import ItemListContainer from './componentes/ItemListContainer';
import ItemDetailContainer from './componentes/ItemDetailContainer';

function App() {
  return (
    <div className="App">
    <Nabvar />
    <ItemListContainer />
    
     
</div>
    );
}

export default App;
